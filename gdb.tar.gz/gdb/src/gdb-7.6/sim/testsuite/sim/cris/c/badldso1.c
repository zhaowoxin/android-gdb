/*
#notarget: cris*-*-elf
#dynamic:
#xerror:
#output: *: could not load ELF interpreter `*' for program `*'\n
 */
#include "hello.c"
