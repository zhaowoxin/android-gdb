/*
#dynamic:
#sim: --sysroot=@exedir@
 */
#include "hello.c"
