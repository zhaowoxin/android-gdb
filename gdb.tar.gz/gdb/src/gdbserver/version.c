#include "server.h"
const char version[] = "7.6";
const char host_name[] = "arm-none-linux-gnueabi";
